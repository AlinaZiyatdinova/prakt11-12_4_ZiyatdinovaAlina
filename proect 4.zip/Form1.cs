﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace практика_12__4_задание_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Car car1 = new Car();
        public string CheckTextBox(string textbox)
        {
            string mes = "";
            int count = 0;
            foreach (char i in textbox)
            {
                if (!Char.IsNumber(i))
                {
                    if (i == ',')
                    {
                        count++;
                        continue;
                    }
                    else
                    mes = "Строка должна содержать только целое число больше нуля!";
                }
            }
            if (count > 1)
            {
                mes = "Строка должна содержать только целое число больше нуля!";
            }
            return mes;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            label4.Text += $" {car1.value_bak}";
            label5.Text += $" {car1.count_value_benz}";
            label6.Text += $" {car1.consumption_benz}";
            label7.Text += $" {car1.probeg}";
            string mes = car1.CheckValue();
            if (mes != "")
            {
                MessageBox.Show($"{mes}", "Сообщение о состоянии автомобиля", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string memory1 = "Количество бензина в баке:";
            if (textBox1.Text != "")
            {
                string checktextbox = CheckTextBox(textBox1.Text);
                if (checktextbox != "")
                {
                    MessageBox.Show($"{checktextbox}", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    double benz = Convert.ToDouble(textBox1.Text);
                    double l = car1.Zapravka(benz);
                    if (l == 0)
                    {
                        label5.Text = memory1;
                        label5.Text += $" {car1.count_value_benz}";
                    }
                    else
                    {
                        MessageBox.Show($"Количество бензина не должно превышать объём бака автомобиля.\nОстаток бензина в колонке = {l}", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        label5.Text = memory1;
                        label5.Text += $" {car1.count_value_benz}";
                    }

                }
            }
            else
                MessageBox.Show($"Поле не заполено", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            string mes = car1.CheckValue();
            if (mes != "")
            {
                MessageBox.Show($"{mes}", "Сообщение о состоянии автомобиля", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
            }
            textBox1.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string memory2 = "Пробег:";
            string memory1 = "Количество бензина в баке:";
            string memory3 = "Расход бензина на 100км:";
            if (textBox2.Text != "")
            {
                string checktextbox = CheckTextBox(textBox2.Text);
                if (checktextbox != "")
                {
                    MessageBox.Show($"{checktextbox}", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (car1.count_value_benz > 0)
                    {
                        double km = Convert.ToDouble(textBox2.Text);
                        double message = car1.Poezdka(km);
                        label5.Text = memory1;
                        label5.Text += $" {car1.count_value_benz}";
                        label7.Text = memory2;
                        label7.Text += $" {car1.probeg}";
                        label6.Text = memory3;
                        label6.Text += $" {car1.consumption_benz}";
                        if (message > 0)
                        {
                            MessageBox.Show($"Бензина в баке автомобиля не хватило.\nОсталось километров: {message}", "Сообщение о состоянии автомобиля", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else if (message <= 0)
                              {
                            MessageBox.Show($"Бензина в баке автомобиля хватило.", "Сообщение о состоянии автомобиля", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        }

                    }
                    else if (car1.count_value_benz <= 0)
                    {
                            MessageBox.Show($"В баке автомобиля нет бензина. Необходима заправка.", "Сообщение о состоянии автомобиля", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
                MessageBox.Show($"Поле не заполено", "Сообщение об ошибке", MessageBoxButtons.OK, MessageBoxIcon.Error);
            textBox2.Text = "";
        }
    }
}
