﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace практика_12__4_задание_
{
    class Car
    {
        public double value_bak = 65;
        public double count_value_benz = 0;
        public double consumption_benz = 7;
        public double probeg = 11000;
        public double d_probeg = 11000;
        public string CheckValue()
        {
            string mes = "";
            if (count_value_benz < 0)
            {
                mes = "Необходимо заправить автомобиль!";
            }
            else if (count_value_benz == value_bak)
            {
                mes = "Заправка не требуется! Бак автомобиля заполнен.";
            }
            return mes;
        }
        public double Zapravka(double value_benz)
        {
            double litr = 0;
            if (value_benz + count_value_benz < value_bak)
            {
                count_value_benz += value_benz;
            }
            else
            {
                litr = (value_benz + count_value_benz) - value_bak ;
                count_value_benz += value_benz;
                count_value_benz = count_value_benz - litr;
            }
            return litr;
        }
        public double Poezdka(double kilometrag)
        {
            while (kilometrag - 100 >= 0 || count_value_benz - consumption_benz > consumption_benz)
            {
                if (kilometrag - 100 < 0)
                { break; }
                else if (count_value_benz - consumption_benz < 0)
                { break; }
                else
                {
                    kilometrag -= 100;
                    count_value_benz = count_value_benz - consumption_benz;
                    probeg += 100;
                    if (probeg > d_probeg+1000)
                    {
                        d_probeg += 1000;
                        consumption_benz += 0.1;
                    }
                }
            }
            return kilometrag;
        }
    }
}
